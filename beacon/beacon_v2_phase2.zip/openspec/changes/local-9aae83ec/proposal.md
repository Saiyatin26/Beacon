# Invariant local-9aae83ec

## Mined rule
condition: `annual_income < 20000 and debt_ratio > 0.6`
consequence: `REJECT`
severity: critical

## Why
Discovered via BEACON Stage 2 invariant mining (hybrid static/dynamic analysis
+ LLM reasoning). Confidence 0.71, graduated to an
enforced oracle: True.

## Evidence
- corroborating traces (normalized): 0.01
- input diversity: 0.07

## Validation
- boundary-probe pass rate: 1.00
- contradictions against existing invariants: 0

## Next step
This proposal feeds Stage 3 (oracle synthesis) if graduated; see
backend/oracle/synthesizer.py.

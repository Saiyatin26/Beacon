# Invariant ollama-0bb6b08e

## Mined rule
condition: `credit_score < 600 and debt_ratio > 0.4`
consequence: `REJECT`
severity: critical

## Why
Discovered via BEACON Stage 2 invariant mining (hybrid static/dynamic analysis
+ LLM reasoning). Confidence 0.93, graduated to an
enforced oracle: True.

## Evidence
- corroborating traces (normalized): 1.00
- input diversity: 0.64

## Validation
- boundary-probe pass rate: 1.00
- contradictions against existing invariants: 0

## Next step
This proposal feeds Stage 3 (oracle synthesis) if graduated; see
backend/oracle/synthesizer.py.
